# samsung-activation-bypass（绕过三星设备激活验证）

> 原模块：\samsung-activation-bypass\ v2 / 作者 **Yufz** / id \samsung-activation-bypass> 本目录内是**重新打包的可用版本**（补齐说明文档，其余内容与原版一致）。

## 它做什么

通过 Magisk / KernelSU 的 **REPLACE** 指令，把系统里的
\/system/app/ActivationDevice_V2\（三星**设备激活校验 App**）整目录**替换为空目录**：

\\ini
# customize.sh
SKIPUNZIP=0
REPLACE="
/system/app/ActivationDevice_V2
"
\
激活校验进程因此无从启动 → 开机不再要求激活。

## 安装

1. 用 Magisk / KernelSU 管理器安装本 zip（**模块**方式，不是 TWRP 刷入）
2. 重启

> KernelSU 用户：管理器 → 模块 → 从本地安装 → 选本 zip → 重启

## 卸载 / 恢复

在管理器里卸载本模块后重启。若要让激活恢复原状，还需要把
\/system/app/ActivationDevice_V2\ 的内容还原（重新刷入原厂 system 分区）。

## ⚠️ 重要：这与你正在用的"持久化绕过"并不相同

在本项目对应的机器上，实测发现 **激活绕过并不是靠这个模块维持的** ——
\/system/app/ActivationDevice_V2\ 里的 apk **已经被真实删除**（持久化在 system 分区），
且 \/data/adb/modules/\ 下**没有任何激活相关模块**：

\\ash
\$ su -c "ls -ld /system/app/ActivationDevice_V2"
drwxr-xr-x 2 root root 4096 /system/app/ActivationDevice_V2     # 目录在，但是空的
\$ su -c "ls -d /data/adb/modules/*activ*"
No such file or directory                                      # 没有激活模块
\
所以：

| 操作 | 会不会触发重新激活 |
| --- | --- |
| 刷写 \oot\ 分区（内核） | ❌ 不会 |
| 启用 / 禁用任意模块（含本模块） | ❌ 不会 |
| 重启 / 刷 TWRP | ❌ 不会 |
| **恢复原厂 system 分区** | ⚠️ 会（把空目录变回带 apk） |
| **格式化 / 擦除 /data** | ✅ **会** |

**本模块的价值**：如果你的机器是"模块式"绕过（即卸载模块后激活会回来），
这个 zip 可以直接复用；如果已经像上面那样持久化到 system，则本模块是**冗余**的备份。

## 免责声明

仅用于**自己拥有**的设备的系统修复与个性化。请遵守当地法律与三星的服务条款。
